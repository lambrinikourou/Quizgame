module quiz {
	requires java.desktop;
}